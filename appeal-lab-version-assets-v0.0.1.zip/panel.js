const signal = document.getElementById("signal");
const momentumScore = document.getElementById("momentumScore");
const appealSignal = document.getElementById("appealSignal");
const roomRead = document.getElementById("roomRead");
const appealMeter = document.getElementById("appealMeter");
const roomMeter = document.getElementById("roomMeter");

const votes = {
  Energy: 0,
  Focus: 0,
  Chaos: 0,
  Teach: 0
};

const signalCopy = {
  Energy: "Energy is leading",
  Focus: "Focus is leading",
  Chaos: "Chaos is rising",
  Teach: "Teaching moment detected"
};

const appealCopy = {
  Energy: "High Heat",
  Focus: "Sharp Focus",
  Chaos: "Volatile",
  Teach: "Curious"
};

const roomCopy = {
  Energy: "Amplify",
  Focus: "Clarify",
  Chaos: "Disrupt",
  Teach: "Explain"
};

function totalVotes() {
  return Object.values(votes).reduce((sum, value) => sum + value, 0);
}

function getLeader() {
  return Object.entries(votes).sort((a, b) => b[1] - a[1])[0];
}

function updateUI(selectedVote) {
  const total = totalVotes();
  const [leader, count] = getLeader();
  const score = Math.min(100, Math.round((count / Math.max(total, 1)) * 100));

  signal.textContent = total === 0 ? "Waiting for room input" : signalCopy[leader];
  momentumScore.textContent = `${score}%`;
  appealSignal.textContent = total === 0 ? "Unformed" : appealCopy[leader];
  roomRead.textContent = total === 0 ? "Listening" : roomCopy[leader];

  appealMeter.style.width = `${score}%`;
  roomMeter.style.width = `${Math.min(100, 35 + total * 12)}%`;

  document.querySelectorAll(".vote-card").forEach((button) => {
    button.classList.toggle("active", button.dataset.vote === selectedVote);
  });
}

document.querySelectorAll(".vote-card").forEach((button) => {
  button.addEventListener("click", () => {
    const vote = button.dataset.vote;
    votes[vote] += 1;
    updateUI(vote);
  });
});

updateUI();
