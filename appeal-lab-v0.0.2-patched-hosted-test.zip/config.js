/* THE APPEAL LAB v0.0.2 — Config Logic */

(function () {
  const twitchExt = window.Twitch && window.Twitch.ext ? window.Twitch.ext : null;

  function text(id, value) {
    const el = document.getElementById(id);
    if (el) {
      el.textContent = value;
    }
  }

  function decodeJwtPayload(token) {
    try {
      const part = token.split(".")[1];
      if (!part) {
        return {};
      }
      const normalized = part.replace(/-/g, "+").replace(/_/g, "/");
      const padded = normalized + "=".repeat((4 - normalized.length % 4) % 4);
      return JSON.parse(atob(padded));
    } catch (error) {
      return {};
    }
  }

  if (twitchExt && typeof twitchExt.onAuthorized === "function") {
    twitchExt.onAuthorized(function (auth) {
      const payload = decodeJwtPayload(auth.token || "");
      const nodeId = payload.user_id || auth.userId || "ANON-NODE";
      text("config-auth-status", "Connected");
      text("node-id", String(nodeId).slice(0, 12));
    });
  } else {
    text("config-auth-status", "Demo Mode");
    text("node-id", "LOCAL-NODE");
  }

  document.querySelectorAll(".toggle").forEach((toggle) => {
    toggle.addEventListener("click", function () {
      toggle.classList.toggle("on");
      toggle.setAttribute("aria-pressed", toggle.classList.contains("on") ? "true" : "false");
    });
  });

  const calibrate = document.getElementById("calibrate-button");
  if (calibrate) {
    calibrate.addEventListener("click", function () {
      const original = calibrate.textContent;
      calibrate.textContent = "System Calibrated";
      text("calibration-state", "Ready for Hosted Test");
      setTimeout(function () {
        calibrate.textContent = original;
      }, 1900);
    });
  }
})();
