# The Appeal Lab — Twitch Extension v0.0.2

The Appeal Lab is a premium static Twitch Extension prototype for audience pulse checks, appeal testing, creator challenges, and creator-facing momentum control.

## Files

style.css
panel.html
panel.js
config.html
live.html
live.js
config.js
README.md

## Twitch Asset Hosting

Panel Viewer Path: panel.html
Config Path: config.html
Live Config Path: live.html
Panel Height: 360

## Scope

- Static front-end hosted-test prototype
- No backend required
- No EBS required
- No Twitch chat-send capability
- No public identity link requirement
- No external CDN dependencies beyond the official Twitch Extension Helper
- Local UI simulation only

## Product Frame

Read the room. Test appeal. Shape momentum.

The Appeal Lab is designed as a creator intelligence layer for live audience psychology. This package simulates the Detection → Resonance → Relay loop through local UI interactions, preparing the product for later authenticated EBS and Extension PubSub expansion.

## Patched review items

- `config.html` now loads `config.js` instead of sharing panel runtime logic.
- The standard Twitch panel width is hardened with a 420px breakpoint.
- Demo chat input uses DOM text insertion rather than `innerHTML`.
- Continuous animations respect `prefers-reduced-motion`.
