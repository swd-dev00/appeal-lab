/* The Appeal Lab — Live Config Console */

(function () {
  const twitchExt = window.Twitch && window.Twitch.ext ? window.Twitch.ext : null;

  const modes = {
    "Room Read": {
      instruction: "Ask the audience what this moment needs next. Use the leading signal to decide whether to teach, intensify, focus, or disrupt.",
      signalGoal: "Detect attention temperature",
      creatorMove: "Respond to the dominant pulse",
      audienceRole: "Vote the room direction",
      prompts: [
        "What does this moment need: more energy, more focus, more chaos, or a breakdown?",
        "If this stream had one missing ingredient right now, what would it be?",
        "Give me the signal. Should I raise the pressure or explain the system?"
      ]
    },
    "Appeal Test": {
      instruction: "Put a concept, take, class topic, joke, or performance beat in front of the audience and measure whether it lands.",
      signalGoal: "Test magnetic pull",
      creatorMove: "Double down or reframe",
      audienceRole: "React to the idea",
      prompts: [
        "Does this land, or does it need a sharper angle?",
        "Would you keep watching if this became the whole segment?",
        "Rate the pull: weak, useful, chaotic, or undeniable?"
      ]
    },
    "Pressure Flip": {
      instruction: "Turn friction into fuel. Use confusion, silence, disagreement, or hesitation as the setup for a live challenge.",
      signalGoal: "Convert dead air",
      creatorMove: "Name the tension and flip it",
      audienceRole: "Choose the pressure point",
      prompts: [
        "What is the tension in the room right now?",
        "Do I simplify this or turn the pressure up?",
        "Pick the pressure point: confusion, boredom, doubt, or chaos."
      ]
    },
    "Aura Spike": {
      instruction: "Amplify the strongest audience signal into a high-energy moment that feels participatory and memorable.",
      signalGoal: "Spike momentum",
      creatorMove: "Perform the winning signal",
      audienceRole: "Push the stream direction",
      prompts: [
        "What would make this moment clip-worthy?",
        "Choose the aura spike: bold take, fast challenge, live lesson, or chaos round.",
        "Give me the move that makes this impossible to ignore."
      ]
    }
  };

  function setText(id, value) {
    const el = document.getElementById(id);
    if (el) {
      el.textContent = value;
    }
  }

  function setMode(modeName) {
    const mode = modes[modeName];
    if (!mode) {
      return;
    }

    setText("active-frame", modeName);
    setText("active-instruction", mode.instruction);
    setText("signal-goal", mode.signalGoal);
    setText("creator-move", mode.creatorMove);
    setText("audience-role", mode.audienceRole);
    setText("prompt-one", mode.prompts[0]);
    setText("prompt-two", mode.prompts[1]);
    setText("prompt-three", mode.prompts[2]);

    document.querySelectorAll(".command-card").forEach(function (button) {
      button.classList.toggle("active", button.dataset.mode === modeName);
    });
  }

  document.querySelectorAll(".command-card").forEach(function (button) {
    button.addEventListener("click", function () {
      setMode(button.dataset.mode);
      setText("live-status", "FRAME ARMED");
    });
  });

  if (twitchExt && typeof twitchExt.onAuthorized === "function") {
    twitchExt.onAuthorized(function () {
      setText("live-status", "PULSE READY");

      if (typeof twitchExt.listen === "function") {
        twitchExt.listen("broadcast", function (target, contentType, message) {
          try {
            const data = JSON.parse(message);
            if (data.type === "MOMENTUM_PULSE") {
              const consoleEl = document.getElementById("live-console");
              if (consoleEl) {
                consoleEl.classList.add("broadcast-flash");
                setTimeout(function () {
                  consoleEl.classList.remove("broadcast-flash");
                }, 900);
              }
              setText("live-status", "MOMENTUM HIT");
            }
          } catch (error) {
            setText("live-status", "PULSE RECEIVED");
          }
        });
      }
    });
  }
})();
