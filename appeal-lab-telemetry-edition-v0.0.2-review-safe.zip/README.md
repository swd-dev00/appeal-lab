# The Appeal Lab — Twitch Extension Telemetry Edition

Version: `0.0.2`

The Appeal Lab is a front-end prototype of a live audience intelligence panel for audience pulse checks, appeal testing, creator challenges, and momentum control.

This hosted-test package is static and review-safe. It simulates the Detection → Resonance → Relay experience locally and prepares the interface for a future Extension Backend Service without sending backend requests in this build.

## Files Included

```text
style.css
panel.html
panel.js
config.html
live.html
live.js
README.md
```

## Twitch Asset Hosting Paths

```text
Panel Viewer Path: panel.html
Config Path: config.html
Live Config Path: live.html
Panel Height: 360
```

## Current Build Scope

- Static front-end hosted-test prototype
- Uses the official Twitch Extension Helper
- No custom backend calls
- No external APIs
- No Twitch chat send capability
- No public identity link required
- Local UI simulation only

## Future Architecture

Future versions may support authenticated pulse events, rolling room resonance scoring, and real-time relay through an Extension Backend Service.

The full system is designed around a Detection → Resonance → Relay loop:

1. Detection: captures explicit viewer pulses through Twitch Extension authentication.
2. Resonance: converts viewer signals into a rolling, time-sensitive Room Resonance Score.
3. Relay: broadcasts dominant audience signals back to active extension clients through Extension PubSub.

Future telemetry should remain aggregate and privacy-safe: no stored message bodies, no unnecessary personal data, and no public identity requirement.
