/* The Appeal Lab — shared panel/config logic */

(function () {
  const twitchExt = window.Twitch && window.Twitch.ext ? window.Twitch.ext : null;

  function safeText(id, value) {
    const el = document.getElementById(id);
    if (el) {
      el.textContent = value;
    }
  }

  function decodeJwtPayload(token) {
    try {
      const part = token.split(".")[1];
      if (!part) {
        return {};
      }

      const normalized = part.replace(/-/g, "+").replace(/_/g, "/");
      const padded = normalized + "=".repeat((4 - normalized.length % 4) % 4);
      return JSON.parse(atob(padded));
    } catch (error) {
      return {};
    }
  }

  if (twitchExt && typeof twitchExt.onAuthorized === "function") {
    twitchExt.onAuthorized(function (auth) {
      const payload = decodeJwtPayload(auth.token || "");
      const nodeId = payload.user_id || auth.userId || "ANON-NODE";

      safeText("auth-status", "TELEMETRY ON");
      safeText("viewer-id", String(nodeId).slice(0, 12));
      safeText("node-peak", "Node-" + String(nodeId).slice(-4));
      safeText("node-high", "Vibe-217");
      safeText("node-rising", "Pulse-089");
    });
  } else {
    safeText("auth-status", "DEMO MODE");
    safeText("viewer-id", "LOCAL-NODE");
    safeText("node-peak", "NeonNinja");
    safeText("node-high", "VibeMaster");
    safeText("node-rising", "PulseRider");
  }

  document.querySelectorAll(".signal-tag").forEach(function (tag) {
    tag.addEventListener("click", function () {
      tag.classList.toggle("selected");
    });
  });

  const submitButton = document.getElementById("submit-btn");
  if (submitButton) {
    submitButton.addEventListener("click", function () {
      const originalText = submitButton.textContent;
      const selectedTags = document.querySelectorAll("#panel-tags .selected");
      const resonance = selectedTags.length > 0 ? "SIGNAL RISING" : "LOW INPUT";

      submitButton.textContent = "PROCESSING SIGNAL...";
      submitButton.style.opacity = "0.55";
      safeText("feedback-note", "Signal entering local resonance window");

      setTimeout(function () {
        submitButton.textContent = "SIGNAL LOGGED";
        submitButton.style.background = "rgba(0, 243, 255, 0.18)";
        submitButton.style.color = "#fff";
        submitButton.style.opacity = "1";

        safeText("room-resonance", resonance);
        safeText("feedback-note", "Room pulse captured for this session");

        const contextInput = document.getElementById("signal-context");
        if (contextInput) {
          contextInput.value = "";
        }

        selectedTags.forEach(function (tag) {
          tag.classList.add("flash");
          setTimeout(function () {
            tag.classList.remove("flash");
          }, 500);
          tag.classList.remove("selected");
        });

        setTimeout(function () {
          submitButton.textContent = originalText;
          submitButton.style.background = "transparent";
          submitButton.style.color = "var(--cyan)";
        }, 1800);
      }, 700);
    });
  }

  document.querySelectorAll(".toggle-switch").forEach(function (toggle) {
    toggle.addEventListener("click", function () {
      toggle.classList.toggle("on");
    });
  });

  const saveConfigButton = document.getElementById("save-config-btn");
  if (saveConfigButton) {
    saveConfigButton.addEventListener("click", function () {
      const originalText = saveConfigButton.textContent;
      saveConfigButton.textContent = "SYSTEM CALIBRATED";
      safeText("config-momentum", "READY");
      safeText("config-dominant", "AWAITING SIGNAL");

      setTimeout(function () {
        saveConfigButton.textContent = originalText;
      }, 1800);
    });
  }
})();
